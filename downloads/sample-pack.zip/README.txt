Fuzzy Chainsaw — placeholder download pack.
Replace with real STL/3MF files after purchase integration.
